package io.packt.metrics;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author hrupp
 */
@ApplicationPath("book-metrics")
public class BookApp extends Application {

}
